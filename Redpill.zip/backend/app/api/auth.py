from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timezone

from ..deps import get_db, get_current_user
from ..models.user import User
from ..core.security import (
    get_password_hash,
    verify_password,
    create_access_token,
)

router = APIRouter(prefix="/v1/auth", tags=["auth"])


# ====== Schematy przychodzących danych ======

class AuthIn(BaseModel):
    email: EmailStr
    password: str


# ====== Helper: jak pakujemy usera dla frontu ======

def _public_user_dict(u: User) -> dict:
    """Co frontend ma wiedzieć o userze."""
    return {
        "id": u.id,
        "email": u.email,
        "rank": u.rank,
        "experience": u.experience,
        "hard_mode": u.hard_mode,
        "timezone": u.timezone,
        "created_at": u.created_at.isoformat() if u.created_at else None,
        # nowe pola – frontend będzie mógł z tego karmić Home
        "xp_mind": u.xp_mind,
        "xp_body": u.xp_body,
        "xp_soul": u.xp_soul,
        "streak_days": u.streak_days,
        "last_active": u.last_active.isoformat() if u.last_active else None,
    }


def _auth_response(u: User) -> dict:
    """To co frontend oczekuje po loginie/rejestracji."""
    jwt_token = create_access_token({"sub": str(u.id)})
    # frontend patrzy na 3 klucze (access / token / jwt),
    # wszystkie mogą być tym samym JWT – robimy tak jak wcześniej
    return {
        "access": jwt_token,
        "token": jwt_token,
        "jwt": jwt_token,
        "user": _public_user_dict(u),
    }


# ====== POST /v1/auth/register ======
@router.post("/register")
async def register(data: AuthIn, db: AsyncSession = Depends(get_db)):
    # 1. czy email już istnieje?
    q = await db.execute(select(User).where(User.email == data.email))
    existing = q.scalars().first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email już istnieje.",
        )

    # 2. utwórz nowego usera z domyślnymi wartościami
    now = datetime.now(timezone.utc)

    u = User(
        email=data.email,
        password_hash=get_password_hash(data.password),
        rank="Adept",
        experience=0,
        hard_mode=False,
        timezone="Europe/Warsaw",
        created_at=now,
        xp_mind=0,
        xp_body=0,
        xp_soul=0,
        streak_days=0,
        last_active=now,
    )

    db.add(u)
    await db.commit()
    await db.refresh(u)

    return _auth_response(u)


# ====== POST /v1/auth/login ======
@router.post("/login")
async def login(data: AuthIn, db: AsyncSession = Depends(get_db)):
    # 1. znajdź usera po mailu
    q = await db.execute(select(User).where(User.email == data.email))
    u = q.scalars().first()

    if not u:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Nieprawidłowy email lub hasło.",
        )

    # 2. sprawdź hasło
    if not verify_password(data.password, u.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Nieprawidłowy email lub hasło.",
        )

    # 3. zaktualizuj last_active + ewentualnie streak logic (na razie tylko last_active)
    u.last_active = datetime.now(timezone.utc)
    db.add(u)
    await db.commit()
    await db.refresh(u)

    return _auth_response(u)


# ====== GET /v1/auth/check ======
# frontend robi to przy odpalaniu apki, żeby od razu wiedzieć czy token dalej ważny
@router.get("/check")
async def check_me(current_user: User = Depends(get_current_user)):
    if not current_user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Brak lub zły token.",
        )

    return {
        "ok": True,
        "user": _public_user_dict(current_user),
    }
