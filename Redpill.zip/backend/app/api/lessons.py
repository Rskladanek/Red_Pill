from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..deps import get_db, get_current_user
from ..models.user import User

router = APIRouter(prefix="/v1", tags=["lessons"])

# ---- Progi rang (używa też progress.py) ----
RANKS = [
    {"name": "Adept",   "xp": 0},
    {"name": "Warrior", "xp": 50},
    {"name": "Knight",  "xp": 120},
    {"name": "Master",  "xp": 250},
    {"name": "Overlord","xp": 500},
]

def _rank_for_xp(total_xp: int) -> str:
    current = "Adept"
    for r in RANKS:
        if total_xp >= r["xp"]:
            current = r["name"]
        else:
            break
    return current

# ---- Lekcje/quizy (z kluczem 'correct' trzymanym tylko na backendzie) ----
LESSON_DATA = {
    "mind": {
        "theory":   {"id": 101, "title": "Status > bycie lubianym",
                     "content": "Nie grasz, żeby cię lubili. Grasz, żeby cię respektowali.\nRóżnica jest prosta: lubią klauna, słuchają lidera.\nCisza + spojrzenie to też komunikat."},
        "practice": {"id": 102, "title": "Nie przepraszaj odruchowo",
                     "content": "Usuń automatyczne 'sorry' za rzeczy niebędące twoją winą.\nZamiast 'sorki, że zawracam głowę' mów: 'Potrzebuję X'."},
        "check":    {"id": 103, "question": "Kto realnie kontroluje rozmowę?",
                     "answers": {"A": "Ten kto mówi najwięcej i najgłośniej.",
                                 "B": "Ten kto kontroluje rytm i nie reaguje emocjonalnie.",
                                 "C": "Ten kto jest najsympatyczniejszy."},
                     "correct": "B"}
    },
    "body": {
        "theory":   {"id": 201, "title": "Twoja postura to reklama",
                     "content": "Prosto = obecny, gryfny. Garb = zmęczony. Barki, szyja, głowa – to ludzie widzą najpierw."},
        "practice": {"id": 202, "title": "Barki w dół",
                     "content": "Wejście: barki nie przy uszach, broda neutralnie, krok spokojny."},
        "check":    {"id": 203, "question": "Perfumy nakładasz…",
                     "answers": {"A": "Na szyję/nadgarstki/klatę – ciepło skóry niesie zapach.",
                                 "B": "Na ubranie, żeby waliło na 5 metrów.",
                                 "C": "Na włosy i do ust."},
                     "correct": "A"}
    },
    "soul": {
        "theory":   {"id": 301, "title": "Twój kręgosłup > ich komfort",
                     "content": "Uleganie by było 'spokojnie' robi z ciebie sterowalnego. To nie dobroć, to bycie miękkim."},
        "practice": {"id": 302, "title": "Twoje DLACZEGO",
                     "content": "Zapisz jedno zdanie: 'Nie mogę być miękki, bo __'. Ma być prawdziwe, bez insta-motywacji."},
        "check":    {"id": 303, "question": "Dziś zgodziłeś się na coś tylko by uniknąć konfliktu?",
                     "answers": {"A": "Tak.", "B": "Nie.", "C": "Prawie tak."},
                     "correct": "B"}
    }
}

def _public_lesson(track: str) -> dict:
    data = LESSON_DATA[track]
    # ukryj 'correct' przed frontendem
    check = dict(data["check"])
    check.pop("correct", None)
    return {"theory": data["theory"], "practice": data["practice"], "check": check}

# ---- Schemat wejścia do odpowiedzi ----
class QuizAnswerIn(BaseModel):
    quiz_id: int
    selected: str  # "A" / "B" / "C"

# ---- XP/Rank logic ----
async def _award_xp(db: AsyncSession, user_id: int, track: str, correct: bool) -> dict:
    user = await db.scalar(select(User).where(User.id == user_id))
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    gain = 5 if correct else 0  # tylko za poprawną
    if gain:
        user.experience += gain
        if track == "mind":
            user.xp_mind += gain
        elif track == "body":
            user.xp_body += gain
        elif track == "soul":
            user.xp_soul += gain

        # sprawdź awans rangi
        new_rank = _rank_for_xp(user.experience)
        rank_up = new_rank != user.rank
        if rank_up:
            user.rank = new_rank
        await db.commit()
        return {"gain": gain, "xp": user.experience, "rank_up": rank_up, "new_rank": user.rank}

    # brak punktów
    await db.commit()
    return {"gain": 0, "xp": user.experience, "rank_up": False, "new_rank": user.rank}

# ---- Endpoints ----
@router.get("/{track}/lesson")
async def get_lesson(track: str):
    track = track.lower()
    if track not in LESSON_DATA:
        raise HTTPException(status_code=404, detail="Unknown track")
    return _public_lesson(track)

@router.post("/{track}/answer")
async def submit_quiz_answer(
    track: str,
    payload: QuizAnswerIn,
    db: AsyncSession = Depends(get_db),
    user_id: int = Depends(get_current_user),
):
    track = track.lower()
    if track not in LESSON_DATA:
        raise HTTPException(status_code=404, detail="Unknown track")

    correct_letter = LESSON_DATA[track]["check"]["correct"]
    is_correct = payload.selected.strip().upper() == correct_letter

    result = await _award_xp(db, user_id, track, is_correct)
    return {
        "correct": is_correct,
        **result,
    }
