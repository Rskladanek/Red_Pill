from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timezone, date

from ..deps import get_db, get_current_user
from ..models.user import User

router = APIRouter(prefix="/v1/progress", tags=["progress"])


# prosta drabinka rang, można potem zmienić
RANKS = [
    ("Adept", 0),
    ("Disciple", 100),
    ("Operator", 300),
    ("Strategist", 600),
    ("Predator", 1000),
    ("Overlord", 1500),
]


def _calc_rank_and_next(total_xp: int):
    current_rank = RANKS[0][0]
    next_rank = RANKS[0][0]
    next_req = None

    for name, req in RANKS:
        if total_xp >= req:
            current_rank = name
        if req > total_xp and next_req is None:
            next_rank = name
            next_req = req

    # jeśli jesteś już najwyżej
    if next_req is None:
        next_req = total_xp
        next_rank = current_rank

    xp_to_next = max(next_req - total_xp, 0)
    return current_rank, xp_to_next, next_rank


def _pct(part: int, total: int) -> int:
    if total <= 0:
        return 0
    p = int((part / total) * 100)
    if p < 0:
        p = 0
    if p > 100:
        p = 100
    return p


@router.get("/summary")
async def get_summary(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    u = current_user

    xp_mind = u.xp_mind or 0
    xp_body = u.xp_body or 0
    xp_soul = u.xp_soul or 0

    total_xp = xp_mind + xp_body + xp_soul

    mind_pct = _pct(xp_mind, total_xp if total_xp > 0 else 1)
    body_pct = _pct(xp_body, total_xp if total_xp > 0 else 1)
    soul_pct = _pct(xp_soul, total_xp if total_xp > 0 else 1)

    # dominująca ścieżka
    dominant = "mind"
    top_val = xp_mind
    if xp_body > top_val:
        dominant = "body"
        top_val = xp_body
    if xp_soul > top_val:
        dominant = "soul"
        top_val = xp_soul

    # rank i xp do next rank
    rank_now, xp_to_next, next_rank = _calc_rank_and_next(total_xp)

    # streak
    streak_days = u.streak_days or 0

    # last_active normalizujemy do ISO8601
    last_active_iso = None
    if u.last_active:
        if isinstance(u.last_active, datetime):
            last_active_iso = u.last_active.isoformat()
        elif isinstance(u.last_active, date):
            last_active_iso = datetime.combine(
                u.last_active, datetime.min.time(), tzinfo=timezone.utc
            ).isoformat()

    # quote dnia (docelowo będzie z tabeli Quote; teraz placeholder)
    quote = "Litość dla siebie jest luksusem niewolników."

    return {
        "mind_pct": mind_pct,
        "body_pct": body_pct,
        "soul_pct": soul_pct,
        "rank": rank_now,
        "xp_total": total_xp,
        "xp_to_next": xp_to_next,
        "streak_days": streak_days,
        "quote": quote,
        "dominant": dominant,
        "xp_mind": xp_mind,
        "xp_body": xp_body,
        "xp_soul": xp_soul,
        "last_active": last_active_iso,
        "next_rank": next_rank,
    }
