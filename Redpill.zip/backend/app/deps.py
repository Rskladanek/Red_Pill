from typing import AsyncGenerator
from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from .models.base import AsyncSessionLocal
from .models.user import User
from .core.security import decode_access_token

# wyciągamy Bearer <token> z nagłówka
bearer_scheme = HTTPBearer(auto_error=False)

# sesja DB dla endpointów
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSessionLocal() as session:
        yield session

# aktualnie zalogowany user na podstawie JWT
async def get_current_user(
    db: AsyncSession = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
) -> User:
    if credentials is None:
        raise HTTPException(status_code=401, detail="Not authenticated")

    token = credentials.credentials

    try:
        payload = decode_access_token(token)
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")

    user_id_raw = payload.get("sub")
    if user_id_raw is None:
        raise HTTPException(status_code=401, detail="Invalid token payload")

    user_id = int(user_id_raw)

    q = await db.execute(select(User).where(User.id == user_id))
    user = q.scalars().first()

    if not user:
        raise HTTPException(status_code=401, detail="User not found")

    return user
