from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .models.base import engine, Base

# import routerów
from .api import auth, health, users, progress, daily_tasks, lessons
# UWAGA: celowo NIE importujemy habits
# from .api import habits  # <- na razie wylatuje

app = FastAPI(
    title="redpill backend",
    version="0.1.0",
)

# CORS żeby frontend (Flutter web na localhost:xxxx) mógł gadać
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # DEV: wszystko otwarte
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# przy starcie serwera - twórz tabele jak ich nie ma
@app.on_event("startup")
async def on_startup():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

# proste ping root
@app.get("/")
async def root():
    return {"status": "ok"}

# REJESTR ROUTERÓW
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(progress.router)
app.include_router(daily_tasks.router)
app.include_router(lessons.router)
app.include_router(health.router)
# NIE ŁADUJEMY habits.router NA RAZIE
