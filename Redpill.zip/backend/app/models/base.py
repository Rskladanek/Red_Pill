from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

# gdzie trzymamy sqlite
DATABASE_URL = "sqlite+aiosqlite:///./redpill.db"

# async engine (aiosqlite = asynchroniczny sqlite driver)
engine = create_async_engine(
    DATABASE_URL,
    echo=False,          # ustaw True jak chcesz spam logów SQL
    future=True,
)

# fabryka sesji async
AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    expire_on_commit=False,
    class_=AsyncSession,
)

# klasa bazowa dla modeli ORM
class Base(DeclarativeBase):
    pass
