from datetime import datetime, date
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import Integer, String, Boolean, DateTime, Date
from .base import Base

class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    email: Mapped[str] = mapped_column(String, unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String)

    rank: Mapped[str] = mapped_column(String, default="Adept")
    experience: Mapped[int] = mapped_column(Integer, default=0)

    hard_mode: Mapped[bool] = mapped_column(Boolean, default=False)
    timezone: Mapped[str] = mapped_column(String, default="Europe/Warsaw")

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=datetime.utcnow
    )

    xp_mind: Mapped[int] = mapped_column(Integer, default=0)
    xp_body: Mapped[int] = mapped_column(Integer, default=0)
    xp_soul: Mapped[int] = mapped_column(Integer, default=0)

    streak_days: Mapped[int] = mapped_column(Integer, default=0)

    # ostatnia aktywność usera; może być null
    last_active: Mapped[date | None] = mapped_column(Date, nullable=True)
