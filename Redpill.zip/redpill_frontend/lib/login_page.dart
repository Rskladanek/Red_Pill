import 'package:flutter/material.dart';
import 'package:redpill_frontend/services/auth_service.dart';
import 'package:redpill_frontend/pages/dashboard_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _loading = false;

  Future<void> _doLogin() async {
    setState(() => _loading = true);
    try {
      final res = await AuthService.login(
        email: _email.text.trim(),
        password: _password.text,
      );

      // res.user jest nie-null (wymuszone w AuthService)
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => DashboardPage(user: res.user)),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Login fail: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _goRegister() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const RegisterPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 380),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: _email, decoration: const InputDecoration(labelText: 'Email')),
                const SizedBox(height: 12),
                TextField(
                  controller: _password,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'Hasło'),
                  onSubmitted: (_) => _doLogin(),
                ),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: _loading ? null : _doLogin,
                  child: _loading ? const CircularProgressIndicator() : const Text('Zaloguj'),
                ),
                TextButton(onPressed: _goRegister, child: const Text('Załóż konto')),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});
  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _email = TextEditingController();
  final _pw = TextEditingController();
  final _pw2 = TextEditingController();
  bool _loading = false;

  Future<void> _doRegister() async {
    if (_pw.text != _pw2.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Hasła się różnią')),
      );
      return;
    }
    setState(() => _loading = true);
    try {
      final res = await AuthService.register(
        email: _email.text.trim(),
        password: _pw.text,
      );
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => DashboardPage(user: res.user)),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Register fail: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 380),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: _email, decoration: const InputDecoration(labelText: 'Email')),
                const SizedBox(height: 12),
                TextField(controller: _pw, obscureText: true, decoration: const InputDecoration(labelText: 'Hasło')),
                const SizedBox(height: 12),
                TextField(controller: _pw2, obscureText: true, decoration: const InputDecoration(labelText: 'Powtórz hasło')),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: _loading ? null : _doRegister,
                  child: _loading ? const CircularProgressIndicator() : const Text('Zarejestruj'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

