import 'package:flutter/material.dart';
import 'package:redpill_frontend/services/auth_service.dart';
import 'package:redpill_frontend/models/user_model.dart';
import 'package:redpill_frontend/login_page.dart';
import 'package:redpill_frontend/pages/dashboard_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp()); // bez const – mniej dramatu przy hot reload
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late Future<UserModel?> _future;

  @override
  void initState() {
    super.initState();
    _future = AuthService.checkSession();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RedPill',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.deepPurple,
        brightness: Brightness.dark,
      ),
      home: FutureBuilder<UserModel?>(
        future: _future,
        builder: (ctx, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }
          final u = snap.data;
          if (u != null) {
            return DashboardPage(user: u);
          }
          return const LoginPage();
        },
      ),
    );
  }
}

