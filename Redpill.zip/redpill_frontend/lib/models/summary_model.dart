class SummaryModel {
  final int streakDays;
  final String rankName;
  final int xpTotal;
  final int xpToNext;
  final String dominantPath; // "MIND" | "BODY" | "SOUL"
  final int pctMind;
  final int pctBody;
  final int pctSoul;
  final String quote;
  final int xpMindToday;
  final int xpBodyToday;
  final int xpSoulToday;

  SummaryModel({
    required this.streakDays,
    required this.rankName,
    required this.xpTotal,
    required this.xpToNext,
    required this.dominantPath,
    required this.pctMind,
    required this.pctBody,
    required this.pctSoul,
    required this.quote,
    required this.xpMindToday,
    required this.xpBodyToday,
    required this.xpSoulToday,
  });

  factory SummaryModel.fromJson(Map<String, dynamic> json) {
    return SummaryModel(
      streakDays: (json["streak_days"] ?? 0) as int,
      rankName: json["rank_name"] ?? json["rank"] ?? "Adept",
      xpTotal: (json["xp_total"] ?? json["experience"] ?? 0) as int,
      xpToNext: (json["xp_to_next"] ?? 0) as int,
      dominantPath: (json["dominant_path"] ?? "MIND").toString().toUpperCase(),
      pctMind: (json["mind_pct"] ?? 0) as int,
      pctBody: (json["body_pct"] ?? 0) as int,
      pctSoul: (json["soul_pct"] ?? 0) as int,
      quote: json["quote"] ??
          "„Nie prosisz świata o pozwolenie żeby być kim jesteś.”",
      xpMindToday: (json["xp_mind_today"] ?? 0) as int,
      xpBodyToday: (json["xp_body_today"] ?? 0) as int,
      xpSoulToday: (json["xp_soul_today"] ?? 0) as int,
    );
  }
}

