class UserModel {
  final int id;
  final String? email;
  final String rank;
  final int experience;
  final int xpMind;
  final int xpBody;
  final int xpSoul;
  final int streakDays;
  final String? lastActive; // ISO
  final bool hardMode;
  final String? timezone;

  UserModel({
    required this.id,
    this.email,
    required this.rank,
    required this.experience,
    required this.xpMind,
    required this.xpBody,
    required this.xpSoul,
    required this.streakDays,
    this.lastActive,
    required this.hardMode,
    this.timezone,
  });

  static UserModel empty() => UserModel(
        id: 0,
        email: null,
        rank: 'Novice',
        experience: 0,
        xpMind: 0,
        xpBody: 0,
        xpSoul: 0,
        streakDays: 0,
        lastActive: null,
        hardMode: false,
        timezone: null,
      );

  factory UserModel.fromJson(Map<String, dynamic> j) {
    int _toInt(dynamic v) {
      if (v == null) return 0;
      if (v is int) return v;
      return int.tryParse(v.toString()) ?? 0;
    }

    final idRaw = j['id'] ?? j['user_id'] ?? 0;
    final id = idRaw is int ? idRaw : int.tryParse(idRaw.toString()) ?? 0;

    return UserModel(
      id: id,
      email: j['email']?.toString(),
      rank: (j['rank'] ?? 'Novice').toString(),
      experience: _toInt(j['experience']),
      xpMind: _toInt(j['xp_mind']),
      xpBody: _toInt(j['xp_body']),
      xpSoul: _toInt(j['xp_soul']),
      streakDays: _toInt(j['streak_days']),
      lastActive: j['last_active']?.toString(),
      hardMode: (j['hard_mode'] == true) || (j['hard_mode']?.toString() == 'true'),
      timezone: j['timezone']?.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'email': email,
        'rank': rank,
        'experience': experience,
        'xp_mind': xpMind,
        'xp_body': xpBody,
        'xp_soul': xpSoul,
        'streak_days': streakDays,
        'last_active': lastActive,
        'hard_mode': hardMode,
        'timezone': timezone,
      };
}

