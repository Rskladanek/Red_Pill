import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:redpill_frontend/models/user_model.dart';
import 'package:redpill_frontend/services/api_service.dart';

class DashboardPage extends StatefulWidget {
  final UserModel user;
  const DashboardPage({super.key, required this.user});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  Map<String, dynamic>? _summary;

  Map<String, dynamic>? _mind;
  Map<String, dynamic>? _body;
  Map<String, dynamic>? _soul;

  bool _loadingSummary = false;
  bool _loadingMind = false;
  bool _loadingBody = false;
  bool _loadingSoul = false;

  // oddzielne zaznaczenia na każdy tor
  final Map<String, String?> _selected = {
    'mind': null,
    'body': null,
    'soul': null,
  };

  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 4, vsync: this);
    _loadAll();
  }

  Future<void> _loadAll() async {
    await Future.wait([_loadSummary(), _loadLessons('mind'), _loadLessons('body'), _loadLessons('soul')]);
  }

  Future<void> _loadSummary() async {
    setState(() => _loadingSummary = true);
    try {
      final s = await ApiService.fetchSummary();
      setState(() => _summary = s);
    } catch (e) {
      debugPrint('fetchSummary error: $e');
    } finally {
      if (mounted) setState(() => _loadingSummary = false);
    }
  }

  Future<void> _loadLessons(String track) async {
    void assign(String t, Map<String, dynamic> data) {
      if (t == 'mind') _mind = data;
      if (t == 'body') _body = data;
      if (t == 'soul') _soul = data;
    }

    setState(() {
      if (track == 'mind') _loadingMind = true;
      if (track == 'body') _loadingBody = true;
      if (track == 'soul') _loadingSoul = true;
    });

    try {
      final raw = await ApiService.fetchLessons(track);
      // gwarantujemy Map<String,dynamic>
      final data = Map<String, dynamic>.from(raw);
      setState(() => assign(track, data));
    } catch (e) {
      debugPrint('fetchLessons($track) error: $e');
    } finally {
      if (!mounted) return;
      setState(() {
        if (track == 'mind') _loadingMind = false;
        if (track == 'body') _loadingBody = false;
        if (track == 'soul') _loadingSoul = false;
      });
    }
  }

  int? _extractQuizId(Map<String, dynamic> data) {
    dynamic v = data['quiz_id'] ?? data['question_id'] ?? data['id'] ?? (data['quiz']?['id']) ?? (data['quiz']?['quiz_id']);
    if (v == null) return null;
    if (v is int) return v;
    return int.tryParse(v.toString());
  }

  Map<String, String> _extractChoices(Map<String, dynamic> data) {
    // próbujemy różne kształty: quiz.choices, choices, options, answers itd.
    dynamic raw = data['choices'] ?? data['options'] ?? data['answers'] ?? data['quiz']?['choices'];
    if (raw is Map) {
      final m = Map<String, dynamic>.from(raw);
      return m.map((k, v) => MapEntry(k.toString(), v.toString()));
    }
    if (raw is List) {
      // mapujemy na A,B,C,...
      final letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
      final map = <String, String>{};
      for (var i = 0; i < raw.length; i++) {
        map[letters[i]] = raw[i].toString();
      }
      return map;
    }
    // fallback – trzy sztuczne
    return const {'A': 'Option A', 'B': 'Option B', 'C': 'Option C'};
  }

  String _extractQuestion(Map<String, dynamic> data) {
    return (data['question'] ??
            data['quiz']?['question'] ??
            data['title'] ??
            data['lesson']?['title'] ??
            'Question')
        .toString();
  }

  Widget _homeTab() {
    final u = widget.user;
    final s = _summary;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Cześć, ${u.email ?? 'user'}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Wrap(spacing: 12, runSpacing: 12, children: [
          _statCard('Rank', u.rank),
          _statCard('XP', (u.experience).toString()),
          _statCard('Mind', u.xpMind.toString()),
          _statCard('Body', u.xpBody.toString()),
          _statCard('Soul', u.xpSoul.toString()),
          _statCard('Streak', '${u.streakDays}d'),
        ]),
        const SizedBox(height: 16),
        if (_loadingSummary) const LinearProgressIndicator(),
        if (!_loadingSummary && s != null)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(const JsonEncoder.withIndent('  ').convert(s)),
            ),
          ),
      ],
    );
  }

  Widget _statCard(String label, String value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(label),
          ],
        ),
      ),
    );
  }

  Future<void> _submit(String track, Map<String, dynamic> data, String answer) async {
    final quizId = _extractQuizId(data);
    if (quizId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Brak quiz_id/question_id')));
      return;
    }
    try {
      await ApiService.sendQuizAnswer(
        track: track,
        quizId: quizId,
        answer: answer,           // <<— WYMAGANE, naprawia 422
        selected: true,
      );
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Wysłano odpowiedź $answer ($track)')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Błąd quiz: $e')));
    }
  }

  Widget _buildTrackTab(String track, Map<String, dynamic>? data, bool loading) {
    if (loading) return const Center(child: Padding(padding: EdgeInsets.all(16), child: CircularProgressIndicator()));
    if (data == null) {
      return Center(
        child: TextButton.icon(
          onPressed: () => _loadLessons(track),
          icon: const Icon(Icons.refresh),
          label: const Text('Odśwież'),
        ),
      );
    }

    final qText = _extractQuestion(data);
    final choices = _extractChoices(data);
    final current = _selected[track];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(qText, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        for (final entry in choices.entries)
          RadioListTile<String>(
            value: entry.key,
            groupValue: current,
            title: Text('${entry.key}. ${entry.value}'),
            onChanged: (val) {
              setState(() => _selected[track] = val);
              if (val != null) _submit(track, data, val);
            },
          ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: current == null ? null : () => _submit(track, data, current),
          icon: const Icon(Icons.send),
          label: const Text('Wyślij'),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('RedPill'),
        bottom: TabBar(
          controller: _tab,
          isScrollable: true,
          tabs: const [
            Tab(icon: Icon(Icons.home), text: 'Home'),
            Tab(icon: Icon(Icons.psychology), text: 'Mind'),
            Tab(icon: Icon(Icons.fitness_center), text: 'Body'),
            Tab(icon: Icon(Icons.self_improvement), text: 'Soul'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _homeTab(),
          _buildTrackTab('mind', _mind, _loadingMind),
          _buildTrackTab('body', _body, _loadingBody),
          _buildTrackTab('soul', _soul, _loadingSoul),
        ],
      ),
    );
  }
}

