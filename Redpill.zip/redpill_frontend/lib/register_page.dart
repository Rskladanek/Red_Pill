import 'package:flutter/material.dart';
import 'pages/dashboard_page.dart';
import 'services/auth_service.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  String _email = "";
  String _password1 = "";
  String _password2 = "";
  bool _loading = false;
  String? _error;

  Future<void> _doRegister() async {
    if (_password1 != _password2) {
      setState(() {
        _error = "Hasła się nie zgadzają.";
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final res = await AuthService.register(
        email: _email.trim(),
        password: _password1,
      );

      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => DashboardPage(user: res.user),
        ),
      );
    } catch (e) {
      setState(() {
        _error = "Rejestracja nie powiodła się.";
      });
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    const bg = Color(0xFF0F0F11);
    final red = const Color(0xffc80032);

    return Scaffold(
      backgroundColor: bg,
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 340),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  "Rejestracja",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.6,
                  ),
                ),
                const SizedBox(height: 24),
                TextField(
                  style: const TextStyle(color: Colors.white),
                  cursorColor: red,
                  decoration: _inputStyle("Email"),
                  onChanged: (v) => _email = v,
                  onSubmitted: (_) => _doRegister(),
                ),
                const SizedBox(height: 12),
                TextField(
                  style: const TextStyle(color: Colors.white),
                  cursorColor: red,
                  obscureText: true,
                  decoration: _inputStyle("Hasło"),
                  onChanged: (v) => _password1 = v,
                  onSubmitted: (_) => _doRegister(),
                ),
                const SizedBox(height: 12),
                TextField(
                  style: const TextStyle(color: Colors.white),
                  cursorColor: red,
                  obscureText: true,
                  decoration: _inputStyle("Powtórz hasło"),
                  onChanged: (v) => _password2 = v,
                  onSubmitted: (_) => _doRegister(),
                ),
                const SizedBox(height: 16),
                if (_error != null)
                  Text(
                    _error!,
                    style: const TextStyle(color: Colors.redAccent),
                  ),
                const SizedBox(height: 16),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: red,
                    foregroundColor: Colors.white,
                    minimumSize: const Size.fromHeight(44),
                  ),
                  onPressed: _loading ? null : _doRegister,
                  child: Text(_loading ? "..." : "Zarejestruj"),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _inputStyle(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.white70),
      enabledBorder: OutlineInputBorder(
        borderSide: const BorderSide(color: Color(0xFF2C2D32)),
        borderRadius: BorderRadius.circular(6),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: const BorderSide(color: Color(0xffc80032)),
        borderRadius: BorderRadius.circular(6),
      ),
    );
  }
}

