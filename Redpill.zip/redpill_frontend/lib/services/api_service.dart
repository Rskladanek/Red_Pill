import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:redpill_frontend/services/auth_service.dart';

const String baseUrl =
    String.fromEnvironment('API_BASE_URL', defaultValue: 'http://127.0.0.1:8000');

Map<String, String> _headers(String? token) => {
      'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };

class ApiService {
  static Future<Map<String, dynamic>> fetchSummary({String? token}) async {
    final t = token ?? await AuthService.currentToken();
    final uri = Uri.parse('$baseUrl/v1/progress/summary');
    final res = await http.get(uri, headers: _headers(t));
    if (res.statusCode != 200) {
      throw Exception('fetchSummary failed ${res.statusCode}: ${res.body}');
    }
    return Map<String, dynamic>.from(jsonDecode(res.body));
  }

  /// track: "mind" | "body" | "soul"
  static Future<Map<String, dynamic>> fetchLessons(String track, {String? token}) async {
    final t = token ?? await AuthService.currentToken();
    final uri = Uri.parse('$baseUrl/v1/$track/lesson');
    final res = await http.get(uri, headers: _headers(t));
    if (res.statusCode != 200) {
      throw Exception('fetchLessons($track) failed ${res.statusCode}: ${res.body}');
    }
    return Map<String, dynamic>.from(jsonDecode(res.body));
  }

  /// Elastyczne – obsłuży stare wywołania (z `questionId` i bez `selected`)
  static Future<Map<String, dynamic>> sendQuizAnswer({
    required String track, // "mind" | "body" | "soul"
    int? quizId,
    int? questionId, // stary kształt – zamienimy na quiz_id
    required String answer,
    bool? selected, // jak null => true
    String? token,
  }) async {
    final t = token ?? await AuthService.currentToken();
    final id = quizId ?? questionId;
    if (id == null) {
      throw Exception('sendQuizAnswer: quizId/questionId is null');
    }

    final uri = Uri.parse('$baseUrl/v1/$track/answer');
    final body = jsonEncode({
      'quiz_id': id,
      'answer': answer,
      'selected': selected ?? true,
    });

    final res = await http.post(uri, headers: _headers(t), body: body);
    if (res.statusCode != 200) {
      throw Exception('sendQuizAnswer($track) failed ${res.statusCode}: ${res.body}');
    }
    return Map<String, dynamic>.from(jsonDecode(res.body));
  }
}

