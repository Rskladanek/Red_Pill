import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:redpill_frontend/models/user_model.dart';

class AuthService {
  static const String _kTokenKey = 'auth_token';
  static const String _kUserKey = 'user_json';
  static const String _baseUrl =
      String.fromEnvironment('API_BASE_URL', defaultValue: 'http://127.0.0.1:8000');

  static String? _memoryToken;

  /// Aktualny token (pobiera z RAM, a jak brak – z SharedPreferences).
  static Future<String?> currentToken() async {
    if (_memoryToken != null && _memoryToken!.isNotEmpty) return _memoryToken;
    final prefs = await SharedPreferences.getInstance();
    final t = prefs.getString(_kTokenKey);
    _memoryToken = t;
    return t;
  }

  static Future<void> _persistSession(String token, UserModel user) async {
    final prefs = await SharedPreferences.getInstance();
    _memoryToken = token;
    await prefs.setString(_kTokenKey, token);
    await prefs.setString(_kUserKey, jsonEncode(user.toJson()));
  }

  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    _memoryToken = null;
    await prefs.remove(_kTokenKey);
    await prefs.remove(_kUserKey);
  }

  /// Zwraca usera z cache jeśli jest (bez pingowania backendu)
  static Future<UserModel?> checkSession() async {
    final prefs = await SharedPreferences.getInstance();
    final tok = prefs.getString(_kTokenKey);
    final uj = prefs.getString(_kUserKey);
    if (tok == null || tok.isEmpty || uj == null || uj.isEmpty) return null;
    final map = Map<String, dynamic>.from(jsonDecode(uj));
    return UserModel.fromJson(map);
  }

  static Future<LoginResult> login({
    required String email,
    required String password,
  }) async {
    final uri = Uri.parse('$_baseUrl/v1/auth/login');
    final res = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );

    if (res.statusCode != 200) {
      throw Exception('LOGIN_${res.statusCode}: ${res.body}');
    }

    final body = Map<String, dynamic>.from(jsonDecode(res.body));
    final token = (body['access_token'] ?? body['token'] ?? '').toString();
    final userMap = (body['user'] is Map)
        ? Map<String, dynamic>.from(body['user'])
        : <String, dynamic>{};

    if (token.isEmpty || userMap.isEmpty) {
      throw Exception('Brak tokena lub usera w odpowiedzi logowania');
    }

    final user = UserModel.fromJson(userMap);
    await _persistSession(token, user);
    return LoginResult(token: token, user: user);
  }

  static Future<LoginResult> register({
    required String email,
    required String password,
  }) async {
    final uri = Uri.parse('$_baseUrl/v1/auth/register');
    final res = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );

    if (res.statusCode != 200) {
      throw Exception('REGISTER_${res.statusCode}: ${res.body}');
    }

    final body = Map<String, dynamic>.from(jsonDecode(res.body));
    final token = (body['access_token'] ?? body['token'] ?? '').toString();
    final userMap = (body['user'] is Map)
        ? Map<String, dynamic>.from(body['user'])
        : <String, dynamic>{};

    if (token.isEmpty || userMap.isEmpty) {
      throw Exception('Brak tokena lub usera w odpowiedzi rejestracji');
    }

    final user = UserModel.fromJson(userMap);
    await _persistSession(token, user);
    return LoginResult(token: token, user: user);
  }
}

class LoginResult {
  final String token;
  final UserModel user; // nie-null, pilnujemy po stronie parsowania
  LoginResult({required this.token, required this.user});
}

