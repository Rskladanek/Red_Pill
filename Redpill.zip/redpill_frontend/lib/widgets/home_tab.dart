import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../models/summary_model.dart';
import 'power_triangle.dart';

class HomeTab extends StatelessWidget {
  final UserModel user;
  final SummaryModel summary;

  const HomeTab({
    super.key,
    required this.user,
    required this.summary,
  });

  Widget _card(BuildContext ctx, Widget child) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1B1F),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: const Color(0xFF2C2D32)),
      ),
      child: child,
    );
  }

  TextStyle get _labelStyle => const TextStyle(
        fontSize: 11,
        letterSpacing: 0.4,
        color: Color(0xFF999999),
        fontWeight: FontWeight.w500,
      );

  TextStyle get _valueStyle => const TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w600,
        color: Colors.white,
      );

  @override
  Widget build(BuildContext context) {
    final red = const Color(0xffc80032);

    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 80),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // CARD 1: profil / ranga / streak / xp
          _card(
            context,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // górny rządek
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // left: ranga + xp
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          summary.rankName,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: red,
                            letterSpacing: 0.4,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          "${summary.xpTotal} XP total",
                          style: _valueStyle.copyWith(fontSize: 13),
                        ),
                        Text(
                          "${summary.xpToNext} do awansu",
                          style: _labelStyle,
                        ),
                      ],
                    ),
                    // right: streak
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          "Streak 🔥",
                          style: _labelStyle,
                        ),
                        Text(
                          "${summary.streakDays} dni",
                          style: _valueStyle,
                        ),
                        Text(
                          "ciąg aktywnych dni",
                          style: _labelStyle,
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                // hard mode / email
                Text(
                  user.email,
                  style: _labelStyle,
                ),
                Text(
                  "Hard mode: ${user.hardMode ? "ON" : "OFF"}",
                  style: _labelStyle,
                ),
              ],
            ),
          ),

          // CARD 2: balans / trójkąt / dominanta
          _card(
            context,
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  "Balans MIND / BODY / SOUL",
                  style: TextStyle(
                    color: red,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                    letterSpacing: 0.4,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  "Twoje aktualne punkty skupienia",
                  style: _labelStyle,
                ),
                const SizedBox(height: 16),
                SizedBox(
                  height: 180,
                  child: PowerTriangle(
                    mindPct: summary.pctMind,
                    bodyPct: summary.pctBody,
                    soulPct: summary.pctSoul,
                  ),
                ),
                const SizedBox(height: 16),
                // procenty
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _statPct("MIND", summary.pctMind, red),
                    _statPct("BODY", summary.pctBody, red),
                    _statPct("SOUL", summary.pctSoul, red),
                  ],
                ),
                const SizedBox(height: 16),
                // dominanta
                Text(
                  "Dominanta: ${summary.dominantPath}",
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: red,
                    letterSpacing: 0.4,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _dominantMeaning(summary.dominantPath),
                  style: _labelStyle.copyWith(fontSize: 12),
                ),
              ],
            ),
          ),

          // CARD 3: quote dnia + xp dzisiaj
          _card(
            context,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Cytat dnia",
                  style: TextStyle(
                    color: red,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                    letterSpacing: 0.4,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  summary.quote,
                  style: const TextStyle(
                    fontStyle: FontStyle.italic,
                    fontSize: 14,
                    color: Colors.white,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 24,
                  runSpacing: 8,
                  children: [
                    _xpToday("Mind XP", summary.xpMindToday),
                    _xpToday("Body XP", summary.xpBodyToday),
                    _xpToday("Soul XP", summary.xpSoulToday),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statPct(String label, int pct, Color color) {
    return Column(
      children: [
        Text(
          label,
          style: TextStyle(
            color: color,
            fontSize: 12,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.4,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          "$pct%",
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: Colors.white,
          ),
        ),
      ],
    );
  }

  String _dominantMeaning(String d) {
    switch (d.toUpperCase()) {
      case "MIND":
        return "MIND = siła narracji / kontrola rozmowy";
      case "BODY":
        return "BODY = wygląd / prezencja / postawa";
      case "SOUL":
        return "SOUL = kręgosłup / sens / zasady";
      default:
        return "";
    }
  }

  Widget _xpToday(String label, int val) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: _labelStyle,
        ),
        Text(
          "$val",
          style: _valueStyle,
        ),
      ],
    );
  }
}

