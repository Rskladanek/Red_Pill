import 'package:flutter/material.dart';
import '../services/api_service.dart';

class QuizBlock extends StatefulWidget {
  final String domain; // "mind" | "body" | "soul"
  final Map<String, dynamic>? quizData;
  final void Function({
    required String pickedKey,
    required bool isCorrect,
    required int gainedXp,
  })? onAnswered;

  const QuizBlock({
    Key? key,
    required this.domain,
    required this.quizData,
    this.onAnswered,
  }) : super(key: key);

  @override
  State<QuizBlock> createState() => _QuizBlockState();
}

class _QuizBlockState extends State<QuizBlock> {
  String? _picked; // "A", "B", ...
  bool _sending = false;

  Future<void> _handlePick(String key) async {
    if (_sending) return;
    if (widget.quizData == null) return;

    setState(() {
      _picked = key;
      _sending = true;
    });

    final quizId = widget.quizData?['id'];
    // backend expects quiz_id:int, selected:String
    try {
      final res = await ApiService.sendQuizAnswer(
        domain: widget.domain,
        quizId: quizId is int ? quizId : int.tryParse('$quizId') ?? 0,
        selected: key,
      );

      // backend może zwracać np:
      // { "correct": true, "xp": 5, "rank_up": {...} }
      final bool isCorrect =
          (res['correct'] == true) || (res['is_correct'] == true);
      final int gainedXp = (res['xp'] ??
              res['xp_awarded'] ??
              res['xp_gained'] ??
              0) is int
          ? (res['xp'] ??
              res['xp_awarded'] ??
              res['xp_gained'] ??
              0) as int
          : 0;

      widget.onAnswered?.call(
        pickedKey: key,
        isCorrect: isCorrect,
        gainedXp: gainedXp,
      );
    } catch (e) {
      debugPrint("Quiz send failed: $e");
      // nic nie zmieniamy w UI poza tym że zaznaczona opcja zostaje
    } finally {
      if (mounted) {
        setState(() {
          _sending = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final quiz = widget.quizData;
    if (quiz == null) {
      return _card(
        child: const Padding(
          padding: EdgeInsets.all(16),
          child: Text(
            "Ładowanie quizu...",
            style: TextStyle(color: Colors.white70),
          ),
        ),
      );
    }

    final String question = quiz['question']?.toString() ?? 'Pytanie';
    final Map<String, dynamic> answersRaw =
        Map<String, dynamic>.from(quiz['answers'] ?? {});
    final answerKeys = answersRaw.keys.toList()..sort(); // ["A","B","C",...]

    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _tag("QUIZ"),
          const SizedBox(height: 12),
          Text(
            question,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              fontSize: 14,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 16),
          ...answerKeys.map((key) {
            final text = answersRaw[key]?.toString() ?? key;
            final isSelected = (_picked == key);

            return GestureDetector(
              onTap: () => _handlePick(key),
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF1E1E22),
                  border: Border.all(
                    color: isSelected
                        ? const Color(0xFFD0004D)
                        : const Color(0xFF2B2B30),
                    width: isSelected ? 1.5 : 1,
                  ),
                ),
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      key,
                      style: TextStyle(
                        fontSize: 13,
                        height: 1.4,
                        color: isSelected
                            ? const Color(0xFFD0004D)
                            : Colors.white,
                        fontWeight:
                            isSelected ? FontWeight.w600 : FontWeight.w400,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        text,
                        style: TextStyle(
                          fontSize: 13,
                          height: 1.4,
                          color: isSelected
                              ? const Color(0xFFD0004D)
                              : Colors.white,
                          fontWeight: isSelected
                              ? FontWeight.w600
                              : FontWeight.w400,
                        ),
                      ),
                    ),
                    if (_sending && isSelected)
                      const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            Color(0xFFD0004D),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _tag(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF2A2A30),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: const Color(0xFFD0004D), width: 1),
      ),
      child: Text(
        label.toUpperCase(),
        style: const TextStyle(
          fontSize: 11,
          height: 1.2,
          fontWeight: FontWeight.w600,
          color: Color(0xFFD0004D),
          letterSpacing: 0.3,
        ),
      ),
    );
  }

  Widget _card({required Widget child}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E22),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: const Color(0xFF2B2B30)),
      ),
      child: child,
    );
  }
}

