import 'package:flutter/material.dart';
import 'package:redpill_frontend/widgets/quiz_block.dart';

const _cardColor = Color(0xFF191A20);
const _borderColor = Color(0xFF2A2A31);

Map<String, dynamic> asMap(dynamic v) =>
    v is Map ? Map<String, dynamic>.from(v) : <String, dynamic>{};

String toStr(dynamic v) => v?.toString() ?? "";

class TrackTab extends StatelessWidget {
  final String title; // "MIND", "BODY", "SOUL"
  final Color accent;
  final Map<String, dynamic> lesson;
  final void Function(int gain, int newXp, bool rankUp) onXpGain;
  final String apiTrack; // "mind" / "body" / "soul"

  const TrackTab({
    super.key,
    required this.title,
    required this.accent,
    required this.lesson,
    required this.onXpGain,
    required this.apiTrack,
  });

  @override
  Widget build(BuildContext context) {
    final theory = asMap(lesson["theory"]);
    final practice = asMap(lesson["practice"]);
    final quiz = asMap(lesson["check"]);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _sectionCard(
            badgeText: "THEORY",
            badgeColor: accent,
            title: toStr(theory["title"]),
            body: toStr(theory["content"]),
          ),
          const SizedBox(height: 16),
          _sectionCard(
            badgeText: "PRACTICE",
            badgeColor: accent,
            title: toStr(practice["title"]),
            body: toStr(practice["content"]),
          ),
          const SizedBox(height: 16),
          QuizBlock(
            track: apiTrack,
            quizData: quiz,
            onXpGain: onXpGain,
          ),
          const SizedBox(height: 80),
        ],
      ),
    );
  }

  Widget _sectionCard({
    required String badgeText,
    required Color badgeColor,
    required String title,
    required String body,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _borderColor, width: 1),
      ),
      padding: const EdgeInsets.all(16),
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // badge
          Container(
            decoration: BoxDecoration(
              color: badgeColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: Text(
              badgeText,
              style: TextStyle(
                color: badgeColor,
                fontWeight: FontWeight.w600,
                fontSize: 12,
                letterSpacing: 1.1,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.w600,
              height: 1.3,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            body,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 14,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}

